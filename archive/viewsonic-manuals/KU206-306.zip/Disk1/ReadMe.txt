============================================
Slim Multimedia Keyboard v2.2(Zippy)
Copyright (c) 2002 WayTech Development, Inc.
All Rights Reserved.
============================================

System Requirements
===================

Before installing the Slim Multimedia Keyboard Driver, please make 
sure that all hardware connections are correct, and 
that the system complies with the following requirements:

* IBM PC compatible system
* Microsoft Windows NT4/95/98/ME/2000/XP(32bit)

Keyboard Interface
===================
1.USB Keyboard:PID:712A
2.PS2 Keyboard:option Scan Code:e001

***********
* Warning *
***********

If you already installed Slim multimedia Keyboard Driver (your 
keyboard can run without this driver), please run uninstall 
program to uninstall your original driver. 

Installation
============

To install the Slim multimedia Keyboard Driver ,please refer to 
the following instructions.

1. Please insert the CD included in your package into your 
   CD-ROM drive. 
2. If your computer is set up to auto-install programs, then 
   Windows will automatically detect the CD and run the 
   "setup.exe". If Windows does	not perform this procedure, 
   Choose RUN from the Windows START Menu. In the Run window
   , type d:\Location\setup.exe (where D: is the location of 
   your CD-ROM drive) to start the installation Wizard.
3. Follow the Wizard's instruction Wizard's on-screen 
   instructions until the software is successfully installed.

Uninstall
=========

To uninstall the driver:

1. From the Windows START Menu, select SETTINGS then CONTROL 
   PANEL.
2. In the Control Panel, double-click the ADD/REMOVE 
   PROGRAMS icon to enter the Add/Remove Programs Properties 
   window.
3. Click the INSTALL / UNINSTALL button.
4. Select MediaKey from the list
5. Click ADD / REMOVE button
6. Confirm the Uninstall

Release Note & Bugs Fixed
=========================
v2.0a 11/21/2001
1.On Jp XP OS,after updated 106key will can't close PC.This is updating 106key issue.
  Update Install98.exe(10/02) and Modify InstallShield to fix this issue.

v2.0b 12/03/2001  
1.Update Install98.exe(11/30) to update 106key be "106 ���{�� (A01) �L�[�{�[�h (Ctrl+�p?)"

v2.1c 12/04/2001
1.Change about version 2.0 to 2.1

v2.1d 12/05/2005
1.Update driver.
  2KDriver-->kbfilter.sys(11/27)
  98and95Driver-->WTKBD.VXD(11/27)
  NT4Driver-->kbfilter.sys(11/27)

v2.1e 12/06/2001
1.Update WdAcess.dll(12/05)

v2.1f 01/11/2002
2002/01/08
1.Update Magickey.reg-->Change "(C)2001 WayTech Development" to "(C)2002 WayTech Development"

v2.1g 01/16/2002
1.Change about version 2.1 to 2.11

v2.2h 06/18/2002
1.Add Support SimpleChinese version
2.Change about version 2.11 to 2.2
3.Fix switch user issue
  -->Update Wdacess.dll and Magickey.exe
