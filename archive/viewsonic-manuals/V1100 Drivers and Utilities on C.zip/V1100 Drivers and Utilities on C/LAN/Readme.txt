Intel(R) Network Adapter Software Version 6.2
Release Notes
April 18, 2002
=============================================

Copyright (C) 2002, Intel Corporation.  All rights reserved.

Intel Corporation assumes no responsibility for errors or omissions in 
this document.  Nor does Intel make any commitment to update the information 
contained herein.

* Other product and corporate names may be trademarks of other companies 
and are used only for explanation and to the owners' benefit, without intent 
to infringe.



Contents
========

-Customer Support
-Other Release Notes
-User Guides




Customer Support
================

- Main Intel web support site: http://support.intel.com

- Network products information: http://www.intel.com/network

- Worldwide access: Intel has technical support centers worldwide.  Many 
  of the centers are staffed by technicians who speak the local languages.  
  For a list of all Intel support centers, the telephone numbers, and the 
  times they are open, visit http://www.intel.com/support/9089.htm.

- Telephone support: US and Canada: 1-916-377-7000 
  (7:00 - 17:00 M-F Pacific Time) 



Other Release Notes
===================

For technical information about supported adapters, open the main.htm
page as described above or view the text files listed here:

- Intel PCI adapters: wiredpci.txt (in the CD root)
- Intel(R) PRO/100 Mobile adapters: \Cardbus\Guide\cardbus.txt
- Intel(R) PRO/Wireless adapters: \Wireless\wireless.txt


User Guides
===========

User's Guides for products supported by this CD are available by
running the Autorun program or by opening the index.htm in the root
directory. 


