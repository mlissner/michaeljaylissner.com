NMP-530 Firmware Version 2.50

Important Notes:

1)  When a Restore to Default is done after upgrade, the new login and password for the NMP will be:
	login:  admin  password:  default

2)  HDMI autodetection is now supported.

3)  HDMI audio is supported but only if HDMI autodetection is enabled.  Otherwsie, a separate analog     audio connection is required.

4)  If some flash files display jagged or rough, access the web UI using a browser, click on     Settings/Browser and change the Adobe Flash Plugin Version to 6.  Apply, Save, and Reboot.

5)  Read Only setting added to Local Storage.  To enable Read and Write, access the web ui and go to     Settngs/Internal Storage and change the Access setting to Read and Write.

6)  Video File Action is now called Local Storage Playback.

7)  If you are using the script command osdSetAlpha, you must edit the line and add "window" before     the parameters.  Example:  mediaplayer.osdSetAlpha (window, 0, 0, 1366, 768, 255).

8)  Caution:  Do not press the reset button for more than 1 second to reboot the unit.

9)  Short Video Clip issue on local storage playback fixed on this release.

10)  Added a progress bar on upgrade process.


Upgrading your NMP-530
1)  Access the web ui and go to Administration/Upgrade Firmware.

2)  Click browse and point the window to the location of firmware (system.fwimg).

3)  Click Start Upgrade.  IMPORTANT:  You will not see any progress bar on the screen.  The NMP     output will turn off which initiates the upgrade process.  DO NOT TURN OFF OR DISCONNECT the NMP     until the system reboots and the web ui starts asking for the login info.  Upgrade usually lasts      anywhere from 30 to 40 minutes.







