
1. Build all necessary components
=================================


You need the 4 files to burn all flash: uboot image, kernel
image, rootfs image and jffs image. There are short instruction
to prepare all of them:


1.1. some precondition
----------------------

1.1.1. Compiler
---------------
You must have PPC cross compiler. We use FreeScale PCS (Platform
Creation Suite). So two FreeScale's kits should be installed:
pcs-3.0.1 and MPC8272ADS.

After the successfully PCS installation, the compiler must
be in:
/opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/bin/powerpc-linux-gcc
and
/opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/bin/powerpc-linux-g++

This is a compiler details:
# /opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/bin/powerpc-linux-gcc -v
Reading specs from /opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/lib/gcc-lib/powerpc-linux/3.3.2/specs
Configured with: /usr/src/RPM/BUILD/crosstool/source/gcc-3.3.2/configure --target=powerpc-linux --host=i686-host_pc-linux-gnu --prefix=/opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2 --with-headers=/opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/powerpc-linux/include --with-local-prefix=/opt/Embedix/usr/local/powerpc-linux/gcc-3.3.2-glibc-2.3.2/powerpc-linux --disable-nls --enable-threads=posix --enable-symvers=gnu --enable-__cxa_atexit --enable-languages=c,c++ --enable-shared --enable-c99 --enable-long-long
Thread model: posix
gcc version 3.3.2

When the compiler exists and works, we may continue to next step.

1.1.2. TFTP server
------------------
You must have working TFTP server.


1.1.3 Flash type
----------------
VERY IMPORTANT NOTE: Please determine which kind of Flash memory
do you use. The two types of Flash memory is supported now:
S29GL256M Flash (64Kb sector size, Piccolo4311 based product) and
S29GL256N Flash (128 Kb sector size, Piccolo4312 based product).

When you follow this instruction please pay attention that the
addresses may differ for these types of Flash memory. Use only
the correct one!


1.1.4 sudo configuration
------------------------
Some of the commands in Build script should be executed under
root permission.  So you should have sudo configured not to ask
password in order to allow to the Build script do its job. Add
string like:

YOU_USER_NAME ALL=(ALL) NOPASSWD: ALL

to the /etc/sudoers file. Note: plase use visudo command. Never
edit /etc/sudoers directly!

1.2. kernel image
-----------------
File:        vmlinux.PPCBoot
Preparation: ./Build kernel

During compilation, kernel configuration menu will appear.
Usually you don't need to change kernel parameters - just
select "exit" and then answer "yes" to "Save configuration
files question?"


1.3. rootfs image
------------------
File:        rootfs.cramfs
Preparation: ./Build rootfs


1.4. JFFS image
---------------
File:        tivella.jffs
Preparation: ./Build tivella



2. Using UBOOT to burn all images
=================================


2.1 Getting uboot prompt
------------------------
Connect serial line and power up the device. Press any key
during the first few seconds. You should get the uboot prompt,
In case of Picollo4300 STB it should be:

IPSTB=>


2.2 Determine uboot location
----------------------------
Issue "flinfo" command on uboot prompt. See a few first lines in
a flash information you get. It should be:

        For the S29GL256M Flash (Piccolo4311 based product)
        -----------------
    FE000000 (RO) FE010000 (RO) FE020000 (RO) FE030000 (RO) FE040000
    FE050000      FE060000      FE070000      FE080000      FE090000

        For the S29GL256N Flash (Piccolo4312 based product)
        -----------------------
    FE000000 (RO) FE020000 (RO) FE040000 (RO) FE060000      FE080000
    FE0A0000      FE0C0000      FE0E0000      FE100000      FE120000

if you see these lines - the uboot already OK, DO NOT TOUCH IT,
AND DO NOT TRY TO REPROGRAM IT!!! If you see (RO) sectors in
other place - you need to burn new uboot on board. See below 2.4
step.


2.3 Setting uboot environment
-----------------------------
Set the correct network environment and uboot parameters by
issuing follow commands to UBOOT:

setenv ipaddr    192.168.12.200
setenv serverip  192.168.12.99
setenv gatewayip 192.168.12.254
setenv netmask   255.255.255.0

        For the S29GL256M Flash (Piccolo4311 based product)
        -----------------
setenv bootargs root=/dev/mtdblock4 ro rootfstype=cramfs console=ttyS0,115200
setenv bootcmd bootm FE050000

        For the S29GL256N Flash (Piccolo4312 based product)
        -----------------------
setenv bootargs root=/dev/mtdblock4 ro rootfstype=cramfs console=ttyS0,115200
setenv bootcmd bootm FE060000

        For the S29GL256N 64MB Flash (Piccolo4313 based product)
        -----------------------
setenv bootargs root=/dev/mtdblock7 ro rootfstype=cramfs console=ttyS0,115200
setenv bootcmd bootm FC060000

saveenv

Of course this is an example. Set "ipaddr" to the IP of the
board, "serverip" to TFTP server IP, "netmask" to the correct
netmask value and "gatewayip" to the IP of default gateway.

"saveenv" command saves all these parameters to uboot-controlled
flash memory, so you need to set the parameters only once.

Now all files you got in previous steps (u-boot.bin,
vmlinux.PPCBoot, rootfs.cramfs and tivella.jffs) copy to TFTP
server to the TFTP accessible directory (usually it is
/tftpboot).

Debug note:
-----------
When debugging it is much more convinient to mount rootfs over
NFS, instead to burn new rootfs image each time. To do that, just
set "bootargs" root parameter to /dev/nfs and set nfsroot and ip
parameters for the "bootargs" variable like follow:

    *  nfsroot=<NFS-server-IP-number>:/path/on/server/to/nfs_root ip=<client-IP-number>::<gateway-IP-number>:<netmask>:<client-hostname>:eth0:off
        OR, for DHCP:
    * nfsroot=<NFS-server-IP-number>:/path/on/server/to/nfs_root ip=dhcp

Example:

setenv bootargs root=/dev/nfs ro nfsroot=192.168.0.5:/home/alex/projects/piccolo/BuildPiccolo/rootfs ip=192.168.0.200:192.168.0.5:192.168.0.1:225.225.225.0:Picollo:eth0:off
setenv bootargs root=/dev/nfs ro nfsroot=192.168.12.99:/home/alexr/piccolo/BuildPiccolo/Picollo4300/rootfs ip=192.168.12.200:192.168.12.99:192.168.12.254:225.225.225.0:Picollo:eth0:off

Then you may save the "bootargs" variable with the "saveenv" command.


2.4 Burn uboot
--------------
ATTENTION - do this ONLY IF YOU HAVE UBOOT NOT IN CORRECT PLACE!!!
See above 2.2 for details.

Issue the follow commands on UBOOT prompt:

        For the S29GL256M Flash (Piccolo4311 based product)
        -----------------
protect off FE000000 FE04FFFF
erase FE000000 FE04FFFF
tftp 00c00000 /tftpboot/u-boot.bin
cp.b 00c00000 FE000000 $(filesize)
protect on FE000000 FE04FFFF
        For the S29GL256N Flash (Piccolo4312 based product)
        -----------------------
tftp 00c00000 /tftpboot/u-boot.siis_20060602
    or
tftp 00c00000 u-boot.siis_20060602
protect off FE000000 FE03FFFF
erase FE000000 FE03FFFF
cp.b 00c00000 FE000000 $(filesize)
protect on FE000000 FE03FFFF

Note that if this step falls, you need to use WireTAP/PowerTAP
to recover the uboot sectors of the flash.

Now, after uboot update, you need to restore all uboot
environment setting (see section 2.3 of this manual).

2.5 Burn kernel
---------------
tftp 00C00000 /tftpboot/vmlinux.PPCBoot
    or
tftp 00C00000 vmlinux.PPCBoot

        For the S29GL256M Flash (Piccolo4311 based product)
        -----------------
erase FE050000 FE1CFFFF
cp.b 00C00000 FE050000 $(filesize)

        For the S29GL256N Flash (Piccolo4312 based product)
        -----------------------
erase FE060000 FE1BFFFF
cp.b 00C00000 FE060000 $(filesize)

        For the S29GL256N 64MB Flash (Piccolo4313 based product)
        -----------------------
erase FC060000 FC1BFFFF
cp.b 00C00000 FC060000 $(filesize)


2.6 Burn rootfs
---------------
tftp 00C00000 /tftpboot/rootfs.cramfs
    or
tftp 00C00000 rootfs.cramfs

        For the S29GL256M Flash (Piccolo4311 based product)
        -----------------
erase FE1D0000 FFE7FFFF
cp.b 00C00000 FE1D0000 $(filesize)

        For the S29GL256N Flash (Piccolo4312 based product)
        -----------------------
erase FE1C0000 FFE7FFFF
cp.b 00C00000 FE1C0000 $(filesize)

        For the S29GL256N 64MB Flash (Piccolo4313 based product)
        -----------------------
See 2.10

Note that sometimes you get the ".... Timeout Erased 459 sectors" message.
Then the "cp.b" command may fail with a "Copy to Flash... Flash not Erased"
message. It is OK, just wait a few minutes and repeat the "cp.b" command.

2.7 Burn tivella JFFS
---------------------
tftp 00C00000 /tftpboot/persist.jffs
    or
tftp 00C00000 persist.jffs

        For 32MB Flash
        --------------
erase FFE80000 FFFFFFFF
cp.b 00C00000 FFE80000 $(filesize)

        For 64MB Flash
        --------------
erase FD9A0000 FDFFFFFF
cp.b 00C00000 FD9A0000 $(filesize)


2.8 Burn root / system FS (Failsafe mode only, S29GL256M Flash)
----------------------------------------------
tftp 00C00000 /tftpboot/rootfs.cramfs
    or
tftp 00C00000 rootfs.cramfs
erase FE1D0000 FEA7FFFF
cp.b 00C00000 FE1D0000 $(filesize)

tftp 00C00000 /tftpboot/tivella.cramfs
    or
tftp 00C00000 tivella.cramfs
erase FEA80000 FF47FFFF
cp.b 00C00000 FEA80000 $(filesize)
erase FF480000 FFE7FFFF
cp.b 00C00000 FF480000 $(filesize)

2.9 Burn root / system FS (Failsafe mode only, S29GL256N Flash)
----------------------------------------------
tftp 00C00000 /tftpboot/rootfs.cramfs
    or
tftp 00C00000 rootfs.cramfs
erase FE1C0000 FEA7FFFF
cp.b 00C00000 FE1C0000 $(filesize)

tftp 00C00000 /tftpboot/tivella.cramfs
    or
tftp 00C00000 tivella.cramfs
erase FEA80000 FF47FFFF
cp.b 00C00000 FEA80000 $(filesize)
erase FF480000 FFE7FFFF
cp.b 00C00000 FF480000 $(filesize)

2.10 Burn root / system FS (Failsafe mode only, S29GL256N-64MB Flash)
----------------------------------------------
tftp 00C00000 /tftpboot/rootfs.cramfs
    or
tftp 00C00000 rootfs.cramfs
erase FE020000  FE81FFFF
cp.b 00C00000 FE020000 $(filesize)

tftp 00C00000 /tftpboot/tivella.cramfs
    or
tftp 00C00000 tivella.cramfs
erase FC1C0000 FD99FFFF
cp.b 00C00000 FC1C0000 $(filesize)
erase FE820000 FFFFFFFF
cp.b 00C00000 FE820000 $(filesize)


3. FLASH MAP
============
Just for your information, the flash mapping is:

        For the S29GL256M Flash (Piccolo4311 based product, 64Kb sector size)
        -----------------------
Uboot           FE000000 - FE03FFFF  /dev/mtd1    4 sectors (   256KB)
Uboot env.      FE040000 - FE04FFFF  /dev/mtd2    1 sector  (   64kb)
Kernel          FE050000 - FE1CFFFF  /dev/mtd3   24 sectors ( 1.5MB)
Rootfs          FE1D0000 - FFE7FFFF  /dev/mtd4  459 sectors (28.6875MB:
                                                32MB-1.5MB-1.5MB-64KB-256KB)
Tivella jffs    FFE80000 - FFFFFFFF  /dev/mtd5   24 sectors ( 1.5MB)


        For the S29GL256M Flash (Piccolo4312 based product, 64Kb sector)
        ----------------------- (FAILSAFE MODE)

Uboot           FE000000 - FE03FFFF  /dev/mtd1    4 sectors ( 256KB)
Uboot env.      FE040000 - FE04FFFF  /dev/mtd2    1 sector  ( 64kB)
Kernel          FE050000 - FE1CFFFF  /dev/mtd3   24 sectors ( 1.375MB)
Rootfs          FE1D0000 - FEA7FFFF  /dev/mtd4  139 sectors ( 8.6875MB )
System1         FEA80000 - FF47FFFF  /dev/mtd5  160 sectors ( 10MB )
System2         FF480000 - FFE7FFFF  /dev/mtd6  160 sectors ( 10MB )
Tivella jffs    FFE80000 - FFFFFFFF  /dev/mtd7   24 sectors ( 1.5MB)

        For the S29GL256N Flash (Piccolo4312 based product, 128Kb sector)
        -----------------------
Uboot           FE000000 - FE03FFFF  /dev/mtd1    2 sectors ( 256KB)
Uboot env.      FE040000 - FE05FFFF  /dev/mtd2    1 sector  ( 128kB)
Kernel          FE060000 - FE1BFFFF  /dev/mtd3   11 sectors ( 1.375MB)
Rootfs          FE1C0000 - FFE7FFFF  /dev/mtd4  230 sectors (28.75MB:
                                                 32MB-1.5MB-1.375MB-128KB-256KB)
Tivella jffs    FFE80000 - FFFFFFFF  /dev/mtd5   12 sectors ( 1.5MB)


        For the S29GL256N Flash (Piccolo4312 based product, 128Kb sector)
        ----------------------- (FAILSAFE MODE)

Uboot           FE000000 - FE03FFFF  /dev/mtd1    2 sectors ( 256KB)
Uboot env.      FE040000 - FE05FFFF  /dev/mtd2    1 sector  ( 128kB)
Kernel          FE060000 - FE1BFFFF  /dev/mtd3   11 sectors ( 1.375MB)
Rootfs          FE1C0000 - FEA7FFFF  /dev/mtd4   70 sectors ( 8.75MB )
System1         FEA80000 - FF47FFFF  /dev/mtd5   80 sectors ( 10MB )
System2         FF480000 - FFE7FFFF  /dev/mtd6   80 sectors ( 10MB )
Tivella jffs    FFE80000 - FFFFFFFF  /dev/mtd7   12 sectors ( 1.5MB)


        For the S29GL256N Flash (Piccolo4313 based product, 64MB Flash)
        ----------------------- (FAILSAFE MODE)

Uboot           FC000000 - FC03FFFF  /dev/mtd1    2 sectors ( 256KB)
Uboot env.      FC040000 - FC05FFFF  /dev/mtd2    1 sector  ( 128kB)
Kernel          FC060000 - FC1BFFFF  /dev/mtd3   11 sectors ( 1.375MB)
System1         FC1C0000 - FD99FFFF  /dev/mtd4  191 sectors ( 23.875MB)
JFFS            FD9A0000 - FDFFFFFF  /dev/mtd5   51 sectors ( 6.375MB)
HRCW            FE000000 - FE01FFFF  /dev/mtd6    1 sector  ( 128KB)
Rootfs          FE020000 - FE81FFFF  /dev/mtd7   64 sectors ( 8MB)
System2         FE820000 - FFFFFFFF  /dev/mtd8  191 sectors ( 23.875MB)
