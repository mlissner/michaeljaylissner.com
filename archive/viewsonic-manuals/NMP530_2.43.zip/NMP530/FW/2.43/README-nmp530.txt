This file is NMP530 related fragments from the README file
==========================================================

1.1.2. TFTP server
------------------
You must have working TFTP server.


2.3 Setting uboot environment
-----------------------------
Set the correct network environment and uboot parameters by
issuing follow commands to UBOOT:

    For example, if you TFTP server is on 192.168.12.99, set follow:
setenv ipaddr    192.168.12.200
setenv serverip  192.168.12.99
setenv gatewayip 192.168.12.254
setenv netmask   255.255.255.0

    The follow parameters must be set exactly as they written here
setenv bootargs root=/dev/mtdblock7 ro rootfstype=cramfs console=ttyS0,115200
setenv bootcmd bootm FC060000

   Now save you changes
saveenv


Now copy all files you need ( vmlinux.PPCBoot, rootfs.cramfs,
tivella.cramfs and persist.jffs) to TFTP server to the TFTP
accessible directory (usually it is /tftpboot).

2.5 Burn kernel
---------------
tftp 00C00000 /tftpboot/vmlinux.PPCBoot
    or
tftp 00C00000 vmlinux.PPCBoot
erase FC060000 FC1BFFFF
cp.b 00C00000 FC060000 $(filesize)


2.7 Burn tivella JFFS
---------------------
tftp 00C00000 /tftpboot/persist.jffs
    or
tftp 00C00000 persist.jffs
erase FD9A0000 FDFFFFFF
cp.b 00C00000 FD9A0000 $(filesize)


2.10 Burn root / system FS (Failsafe mode only, S29GL256N-64MB Flash)
----------------------------------------------
tftp 00C00000 /tftpboot/rootfs.cramfs
    or
tftp 00C00000 rootfs.cramfs
erase FE020000  FE81FFFF
cp.b 00C00000 FE020000 $(filesize)

tftp 00C00000 /tftpboot/tivella.cramfs
    or
tftp 00C00000 tivella.cramfs
erase FC1C0000 FD99FFFF
cp.b 00C00000 FC1C0000 $(filesize)
erase FE820000 FFFFFFFF
cp.b 00C00000 FE820000 $(filesize)


3. FLASH MAP
============
Just for your information, the flash mapping is:

Uboot           FC000000 - FC03FFFF  /dev/mtd1    2 sectors ( 256KB)
Uboot env.      FC040000 - FC05FFFF  /dev/mtd2    1 sector  ( 128kB)
Kernel          FC060000 - FC1BFFFF  /dev/mtd3   11 sectors ( 1.375MB)
System1         FC1C0000 - FD99FFFF  /dev/mtd4  191 sectors ( 23.875MB)
JFFS            FD9A0000 - FDFFFFFF  /dev/mtd5   51 sectors ( 6.375MB)
HRCW            FE000000 - FE01FFFF  /dev/mtd6    1 sector  ( 128KB)
Rootfs          FE020000 - FE81FFFF  /dev/mtd7   64 sectors ( 8MB)
System2         FE820000 - FFFFFFFF  /dev/mtd8  191 sectors ( 23.875MB)
